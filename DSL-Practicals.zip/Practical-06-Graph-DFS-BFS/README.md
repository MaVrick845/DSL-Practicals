# Practical-06-Graph-DFS-BFS

Graph Traversals: DFS (Adjacency Matrix) and BFS (Adjacency List).
