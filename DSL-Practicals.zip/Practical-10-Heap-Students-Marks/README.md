# Practical-10-Heap-Students-Marks

Find Max and Min Marks using Heap.
