# Practical-08-Optimal-BST
# Optimal Binary Search Tree using Dynamic Programming.

# Code goes here...