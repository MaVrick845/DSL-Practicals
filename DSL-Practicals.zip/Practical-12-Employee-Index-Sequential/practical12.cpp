# Practical-12-Employee-Index-Sequential
# Employee Information using Index Sequential File System.

# Code goes here...