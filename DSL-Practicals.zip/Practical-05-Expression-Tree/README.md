# Practical-05-Expression-Tree

Expression Tree creation from Prefix and Postorder traversal.
